def function(x):
    y = 3*(x**2) + 2*x + 3
    return y

# Le Δ est toujours positif quel que soit x appartient a R donc on a pas besoin de definir aussi la fonction de Δ