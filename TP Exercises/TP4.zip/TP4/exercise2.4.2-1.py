# Function of absolute number
def valeur_abs(x):
    return abs(x)

